from pathlib import Path
import json,hashlib,subprocess,time
r=Path(__file__).resolve().parents[2];o=Path(__file__).parent;m=json.loads((r/'dist/migration229/ARTIFACTS.json').read_text(encoding='utf-8'));assert m['sourceCommit']=='4ec25b757ada7715b250226cb6b258231fbae8eb' and m['acceptedForUserTesting'];results=[]
artifacts=[('android','huevia-0.31.0-dev-229-android-arm64.apk'),('ios','huevia-0.31.0-dev-229-ios-unsigned.ipa')]
for platform,name in artifacts:
 p=r/'dist/migration229'/name;expected=next(a for a in m['artifacts'] if a['file']==name);b=p.read_bytes();assert len(b)==expected['bytes'] and hashlib.sha256(b).hexdigest()==expected['sha256']
for stage in ['draft','publish']:
 for platform,name in artifacts:
  expected=next(a for a in m['artifacts'] if a['file']==name);args=['node','online-library/scripts/prepare-mobile-release.mjs',str(r/'dist/migration229'/name),'--notes-file',str(o/'release-notes.txt')]
  args += ['--upload-draft'] if stage=='draft' else ['--publish','--confirm','PUBLISH 229 '+expected['sha256'],'--verify-public']
  started=time.time()
  with (o/f'{platform}-{stage}.log').open('w',encoding='utf-8') as f:p=subprocess.run(args,cwd=r,stdout=f,stderr=subprocess.STDOUT)
  results.append({'stage':stage,'platform':platform,'exit':p.returncode,'sha256':expected['sha256'],'seconds':round(time.time()-started,2)});(o/'pipeline-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
  if p.returncode:raise SystemExit(p.returncode)
(o/'pipeline-complete.json').write_text(json.dumps({'version':229,'published':True,'bothPlatformsPublicBytesVerified':True},indent=2)+'\n',encoding='utf-8')
