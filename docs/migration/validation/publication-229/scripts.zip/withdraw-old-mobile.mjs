import {readFile,writeFile} from 'node:fs/promises';
import {PUBLIC_ORIGIN} from '../../online-library/scripts/cloud-tools.mjs';
const here=new URL('./',import.meta.url),read=async n=>JSON.parse(await readFile(new URL(n,here),'utf8'));
const pipeline=await read('pipeline-complete.json');if(!pipeline.published||!pipeline.bothPlatformsPublicBytesVerified)throw Error('BOTH_NEW_RELEASES_MUST_BE_PUBLIC_AND_VERIFIED');
const metadata=JSON.parse(await readFile(new URL('../../dist/migration229/ARTIFACTS.json',import.meta.url),'utf8'));
const session=JSON.parse(await readFile(new URL('../../online-library/.local/community-admin-session.json',import.meta.url),'utf8'));
const base=PUBLIC_ORIGIN+'/preset-library';
async function request(path,method='GET',body){
 const response=await fetch(base+path,{method,redirect:'error',signal:AbortSignal.timeout(30000),headers:{Cookie:session.cookie,Origin:PUBLIC_ORIGIN,'X-CSRF-Token':session.csrfToken,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});
 const data=await response.json();if(!response.ok)throw Error('RELEASE_API_'+response.status+'_'+data.error?.code);return data;
}
const before=[];const results=[];
for(const [platform,path,suffix] of [['android','/api/next/releases','android-arm64.apk'],['ios','/api/ios/releases','ios-unsigned.ipa']]){
 const rows=(await request(path)).items;before.push({platform,path,items:rows});
 const expected=metadata.artifacts.find(a=>a.file.endsWith(suffix));const current=rows.find(x=>x.versionCode===229&&x.sha256===expected.sha256&&x.status==='published');if(!current)throw Error('NEW_RELEASE_NOT_PUBLISHED_'+platform);
 const prior=rows.filter(x=>x.versionCode<229&&x.status==='published');
 for(const old of prior){
  if(old.channel!=='beta')throw Error('UNEXPECTED_OLD_CHANNEL');
  const changed=(await request(path+'/'+old.id+'/withdraw','POST',{expectedRevision:old.revision,confirmation:'WITHDRAW '+old.versionCode+' '+old.sha256})).release;
  if(changed.id!==old.id||changed.status!=='withdrawn'||changed.sha256!==old.sha256)throw Error('WITHDRAW_RESULT_MISMATCH');
  results.push({platform,id:old.id,versionCode:old.versionCode,sha256:old.sha256,status:changed.status,downloadUrl:old.downloadUrl});
 }
}
await writeFile(new URL('old-mobile-inventory-before.json',here),JSON.stringify(before,null,2)+'\n');
await writeFile(new URL('withdraw-results.json',here),JSON.stringify({complete:true,results},null,2)+'\n');
console.log(JSON.stringify({complete:true,withdrawn:results.length}));
