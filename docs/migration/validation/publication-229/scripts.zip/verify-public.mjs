import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {PUBLIC_ORIGIN} from '../../online-library/scripts/cloud-tools.mjs';
const here=new URL('./',import.meta.url),read=async n=>JSON.parse(await readFile(new URL(n,here),'utf8'));
if(!(await read('withdraw-results.json')).complete)throw Error('WITHDRAWAL_INCOMPLETE');
const metadata=JSON.parse(await readFile(new URL('../../dist/migration229/ARTIFACTS.json',here),'utf8'));
const report={version:229,pageChecks:[],latestChecks:[],oldDownloadChecks:[],complete:false};
const headers={'Cache-Control':'no-cache'};
for(const [origin,page,localSource,script] of [[PUBLIC_ORIGIN,PUBLIC_ORIGIN+'/preset-library/download/','download/download.js','download.js?v=228'],['https://huevia.cc','https://huevia.cc/preset-library/download/','download/download.js','download.js?v=228'],['https://huevia.cc','https://huevia.cc/','home/home.js','home.js?v=228']]){
 const response=await fetch(page,{headers,signal:AbortSignal.timeout(30000)}),html=await response.text();
 if(!response.ok||new URL(response.url).origin!==origin||/data-edition|id="android-editions"/.test(html)||!html.includes(script))throw Error('PAGE_MISMATCH_'+page);
 const scriptUrl=new URL('./'+script,response.url),jsResponse=await fetch(scriptUrl,{headers,signal:AbortSignal.timeout(30000)}),javascript=await jsResponse.text();
 const expected=await readFile(new URL('../../online-library/'+localSource,here),'utf8');if(!jsResponse.ok||javascript!==expected)throw Error('SCRIPT_MISMATCH_'+origin);
 report.pageChecks.push({url:response.url,status:response.status,legacyEditionSelectorPresent:false,scriptSha256:createHash('sha256').update(javascript).digest('hex'),scriptMatchesReviewedSource:true,qualification:'Page script unchanged from228; it loads current release metadata dynamically.'});
}
for(const origin of [PUBLIC_ORIGIN,'https://huevia.cc']){
 for(const platform of ['android','ios','legacy']){
  const path=platform==='ios'?'/ios/releases/latest?bundleId=cc.huevia.next':'/releases/latest?packageName='+(platform==='legacy'?'cc.huevia':'cc.huevia.next');
  const response=await fetch(origin+'/preset-library'+path+'&channel=beta',{headers,signal:AbortSignal.timeout(30000)}),data=await response.json();if(!response.ok)throw Error('LATEST_HTTP_'+response.status);
  if(platform==='legacy'){if(data.release!==null)throw Error('LEGACY_STILL_AVAILABLE');}
  else{const suffix=platform==='ios'?'ios-unsigned.ipa':'android-arm64.apk',expected=metadata.artifacts.find(x=>x.file.endsWith(suffix));if(data.release?.versionCode!==229||data.release.sha256!==expected.sha256||data.release.byteLength!==expected.bytes)throw Error('CURRENT_RELEASE_MISMATCH_'+platform);}
  report.latestChecks.push({origin,platform,status:response.status,versionCode:data.release?.versionCode??null,sha256:data.release?.sha256??null,downloadUrl:data.release?.downloadUrl??null,reason:data.reason});
 }
}
const previous=JSON.parse(await readFile(new URL('../../docs/migration/validation/publication-228/public-verification.json',here),'utf8'));
const old=previous.oldDownloadChecks.map(x=>({platform:x.platform,id:x.id,versionCode:x.versionCode,url:x.url}));
const prior=await read('old-mobile-inventory-before.json');
for(const list of prior)for(const row of list.items.filter(x=>x.versionCode<229)){
 const u=new URL(row.downloadUrl);if(u.origin!==PUBLIC_ORIGIN||u.search||u.hash)throw Error('UNEXPECTED_OLD_URL');
 for(const url of [u.href,'https://huevia.cc'+u.pathname])old.push({platform:list.platform,id:row.id,versionCode:row.versionCode,url});
}
const unique=[...new Map(old.map(x=>[x.url,x])).values()];let index=0;
async function worker(){while(index<unique.length){const item=unique[index++],response=await fetch(item.url,{redirect:'manual',headers,signal:AbortSignal.timeout(30000)});await response.body?.cancel();if(response.status!==404)throw Error('OLD_DOWNLOAD_AVAILABLE_'+item.id+'_'+response.status);report.oldDownloadChecks.push({...item,status:response.status});}}
await Promise.all(Array.from({length:4},worker));report.complete=true;report.mainHomepageVerified=true;report.bothReleaseManifestsVerified=true;
await writeFile(new URL('public-verification.json',here),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({complete:true,pageChecks:report.pageChecks.length,latestChecks:report.latestChecks.length,oldAddressesBlocked:report.oldDownloadChecks.length}));
