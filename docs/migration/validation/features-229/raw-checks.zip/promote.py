from pathlib import Path
import json,hashlib,shutil,subprocess,datetime
r=Path(__file__).resolve().parents[2];o=Path(__file__).parent;d=r/'docs/migration/validation/features-229';out=r/'dist/migration229';out.mkdir(exist_ok=True)
s=json.loads((o/'source.json').read_text());src=s['sourceCommit'];assert src=='4ec25b757ada7715b250226cb6b258231fbae8eb';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==src
assert subprocess.run(['git','diff','--quiet','--','cross-platform/app','cross-platform/core','cross-platform/native'],cwd=r).returncode==0
ci=json.loads((d/'apple/ci-result.json').read_text());assert ci['sourceCommit']==src and ci['conclusion']=='success' and ci['flutterTestsPassed']>=731 and ci['uiKitTestsPassed']==5 and ci['nativeScenariosPassed']>=1 and ci['publicInternetAppleIsolationPassed'] and ci['nativeForegroundSnapshotFixturePassed']
assert json.loads((o/'android-release-result.json').read_text())=={'sourceCommit':src,'exit':0,'abis':['android-arm64','android-x64']}
signed=json.loads((d/'android-signing-alignment.json').read_text());assert len(signed)==2 and all(v['apksignerVerified'] and v['zipalign16KiBVerified'] and v['allLoadSegments16KiBVerified'] for v in signed)
usb=json.loads((d/'usb-directory-result.json').read_text());assert usb['checksPassed']==124 and usb['sourceCommit']==src
ui=json.loads((d/'connection-ui-result.json').read_text());assert ui['sourceCommit']==src and ui['installedRelease'] and ui['releaseVersionCode']==229
rows=[]
for suffix,platform,abi in [('android-arm64.apk','Android','arm64'),('android-x64.apk','Android','x64'),('ios-unsigned.ipa','iOS','arm64')]:
 name='huevia-0.31.0-dev-229-'+suffix;p=o/'package-candidates'/name;b=p.read_bytes();sha=hashlib.sha256(b).hexdigest()
 if platform=='Android': assert next(x for x in signed if x['abi']==abi)['sha256']==sha
 else: assert sha=='f1919917d4e042c1974f87e62dfe62c8864cbb72c992b9b6ea7e54accaec87dd'
 target=out/name
 if target.exists():assert target.read_bytes()==b,'Never replace a different candidate with the same version'
 else:shutil.copy2(p,target)
 assert target.read_bytes()==b
 rows.append({'file':name,'platform':platform,'abi':abi,'unsigned':platform=='iOS','bytes':len(b),'sha256':sha,'sourceCommit':src,'acceptedForUserTesting':True,'published':False})
meta={'build':229,'versionCode':229,'versionName':'0.31.0-dev','appName':'Huevia','sourceCommit':src,'sourceFrozen':True,'acceptedForUserTesting':True,'productionRelease':False,'published':False,'approval':'User selected design A and requested Android/iOS test packages after checks pass. Do not publish229.','checks':{'flutterFullMac':ci['flutterTestsPassed'],'uiKit':ci['uiKitTestsPassed'],'nativeScenarios':ci['nativeScenariosPassed'],'usbDirectoryJvm':124,'cameraRegressionDistinct':58,'androidActualReleaseUi':True,'androidSigningAnd16KiB':True,'physicalZ6IIUsbVerified':False},'artifacts':rows}
(out/'ARTIFACTS.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');(out/'SHA256SUMS.txt').write_text(''.join(v['sha256']+'  '+v['file']+'\n' for v in rows),encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Huevia 229 测试包

仅供用户测试，未发布。iOS 为未签名 IPA，需要自行签名安装。Android 手机使用 android-arm64.apk；android-x64.apk 供模拟器验证。

- 连接页采用已确认的 A 方案：顶部 Wi-Fi／USB 双标签，新连接默认 Wi-Fi；切换方式不直接断开已有会话。
- USB 目录增加空卡槽处理与有限重试，并补充存储／照片枚举诊断。
- 重新连接失败后刷新真实连接状态，避免显示失效的旧会话。

已通过 macOS 全量 731 项 Flutter 测试、5 项 UIKit 检查、1 个原生场景及 Android 独立 USB helper 的 124 项边界检查；Android 两个 release 包通过签名和 16 KiB 对齐检查，已安装 x64 release 验证实际连接页面。

Z6 II USB 实机尚未验证。请优先测试原数据线连接后的相机照片目录、缩略图、JPEG／NEF 下载，以及返回原功能后的连接保持与重连。

文件大小、SHA-256 和冻结源码提交见 ARTIFACTS.json、SHA256SUMS.txt。
''',encoding='utf-8',newline='\n')
s.update(acceptedForLocalTesting=True,acceptedForUserTesting=True,acceptedForDelivery=False,status='accepted-for-user-testing-only',artifacts=rows,checks=meta['checks']);(o/'source.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');shutil.copy2(o/'source.json',d/'source.json');shutil.copy2(out/'ARTIFACTS.json',d/'ARTIFACTS.json')
for n in ['analyze.log','android-arm64-release-result.json','android-x64-release-result.json','android-release-result.json','camera-final-tests.jsonl','camera-connection-isolated.log','isolated-recovery-result.json','isolated-recovery-complete.json','flutter-full-result.json','verifier-selftests-result.json']:shutil.copy2(o/n,d/n)
print(json.dumps({'acceptedForUserTesting':True,'published':False,'sourceCommit':src,'artifacts':rows},ensure_ascii=False))
