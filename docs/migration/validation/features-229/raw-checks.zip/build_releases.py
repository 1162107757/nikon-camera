from pathlib import Path
import subprocess,json,shutil,os,time
r=Path(__file__).resolve().parents[2];o=Path(__file__).parent;stage=o/'package-candidates';stage.mkdir(exist_ok=True)
s=json.loads((o/'source.json').read_text())['sourceCommit'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==s;subprocess.run(['git','diff','--exit-code','--','cross-platform/app'],cwd=r,check=True)
for abi in ['android-arm64','android-x64']:
 started=time.time()
 with (o/f'{abi}-release.log').open('w',encoding='utf-8') as log:
  p=subprocess.run(['python','cross-platform/tool/android_build.py','--sdk','D:/dev/Android/Sdk','--java','D:/dev/Java/jdk-17.0.19','--offline','--mode','release','--abi',abi],cwd=r,stdout=log,stderr=subprocess.STDOUT)
 (o/f'{abi}-release-result.json').write_text(json.dumps({'sourceCommit':s,'abi':abi,'exit':p.returncode,'seconds':round(time.time()-started,2)},indent=2),encoding='utf-8')
 if p.returncode: raise SystemExit(p.returncode)
 suffix='arm64' if abi=='android-arm64' else 'x64'
 shutil.copy2(r/'cross-platform/app/build/app/outputs/apk/release/app-release.apk',stage/f'huevia-0.31.0-dev-229-android-{suffix}.apk')
 for source,name in [('cross-platform/app/build/app/outputs/mapping/release/mapping.txt',f'{suffix}-mapping.txt'),('.tooling/cross-platform187/android-proxy-build.log',f'{suffix}-gradle.log')]: shutil.copy2(r/source,o/name)
(o/'android-release-result.json').write_text(json.dumps({'sourceCommit':s,'exit':0,'abis':['android-arm64','android-x64']},indent=2),encoding='utf-8')
