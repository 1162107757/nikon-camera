from pathlib import Path
import subprocess,xml.etree.ElementTree as E,re,time,json
r=Path(__file__).resolve().parents[2];o=Path(__file__).parent;d=o/'ui';d.mkdir(exist_ok=True);a=['D:/dev/Android/Sdk/platform-tools/adb.exe','-s','emulator-5584']
def adb(*args): return subprocess.check_output(a+list(args),timeout=30)
def tree():
 last=None
 for _ in range(3):
  try:
   v=adb('shell','uiautomator','dump','/sdcard/huevia229-ui.xml');assert b'dumped to:' in v and b'ERROR' not in v
   raw=adb('shell','cat','/sdcard/huevia229-ui.xml');assert E.fromstring(raw).tag=='hierarchy';return raw
  except (subprocess.SubprocessError,E.ParseError,AssertionError) as e: last=e;time.sleep(.3)
 raise RuntimeError('Fresh UI hierarchy unavailable') from last
def snap(name):
 raw=tree();(d/(name+'.xml')).write_bytes(raw);(d/(name+'.png')).write_bytes(adb('exec-out','screencap','-p'));return [(n.get('text') or n.get('content-desc'),n.get('bounds')) for n in E.fromstring(raw).iter('node') if n.get('text') or n.get('content-desc')]
def tap(label):
 nodes=[n for n in E.fromstring(tree()).iter('node') if label in (n.get('text'),n.get('content-desc'))];assert nodes,'No visible '+label;x1,y1,x2,y2=map(int,re.findall(r'\d+',nodes[0].get('bounds')));adb('shell','input','tap',str((x1+x2)//2),str((y1+y2)//2))
if __name__=='__main__': print(snap('launch'))
