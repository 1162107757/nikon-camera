from pathlib import Path
import json,shutil
r=Path('D:/dev/ai-project/nikon-camera');o=r/'.tooling/next229';d=r/'docs/migration/validation/features-229';src=json.loads((o/'source.json').read_text())['sourceCommit'];results={}
for log in ['camera-final-tests.jsonl','camera-connection-isolated.log']:
 suites={};tests={}
 for l in (o/log).read_text(encoding='utf-8').splitlines():
  try:v=json.loads(l)
  except ValueError:continue
  if v.get('type')=='suite':suites[v['suite']['id']]=Path(v['suite']['path']).as_posix()
  if v.get('type')=='testStart':tests[v['test']['id']]=v['test']
  if v.get('type')=='testDone' and not v.get('hidden',False):
   t=tests[v['testID']];results[(suites[t['suiteID']],t['name'])]=v['result']
assert results and all(x=='success' for x in results.values()),'Not every distinct camera case succeeded'
(d/'camera-regression.json').write_text(json.dumps({'sourceCommit':src,'distinctTestsPassed':len(results),'groupInvocationExit':1,'isolatedConnectionSuiteExit':0,'qualification':'Grouped Windows invocation had one incomplete test with no assertion error. The full connection suite was rerun in isolation and all its cases passed. Counts merge by normalized source file and exact test name. Full frozen-source Mac execution is recorded separately.','cases':[{'file':Path(k[0]).name,'test':k[1],'result':v} for k,v in sorted(results.items())]},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ['connection-wifi','connection-usb-empty']:
 for extension in ['png','xml']:shutil.copy2(o/'ui'/f'{name}.{extension}',d/f'{name}.{extension}')
for source,target in [('connection-ui-result.json','connection-ui-result.json'),('usb-jvm.log','usb-directory-jvm.log'),('source.json','source.json')]:shutil.copy2(o/source,d/target)
(d/'usb-directory-result.json').write_text(json.dumps({'sourceCommit':src,'checksPassed':124,'helperCompilationExit':0,'helperRuntimeExit':0,'source':{'helper':'cross-platform/app/android/app/src/main/java/cc/huevia/sharedapp/UsbPhotoDirectory.java','test':'cross-platform/native/tests/UsbPhotoDirectoryBoundaryTest.java'},'physicalZ6IIUsbVerified':False,'qualification':'Pure JVM fake-boundary execution of the Android-independent helper. Native adapter compiled by both release builds; not physical USB camera validation.'},indent=2)+'\n',encoding='utf-8')
print('Merged camera regression unique passes:',len(results))
